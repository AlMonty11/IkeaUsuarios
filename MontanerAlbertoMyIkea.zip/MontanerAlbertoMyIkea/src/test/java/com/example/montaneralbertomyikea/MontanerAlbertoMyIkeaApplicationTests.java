package com.example.montaneralbertomyikea;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MontanerAlbertoMyIkeaApplicationTests {

    @Test
    void contextLoads() {
    }

}
