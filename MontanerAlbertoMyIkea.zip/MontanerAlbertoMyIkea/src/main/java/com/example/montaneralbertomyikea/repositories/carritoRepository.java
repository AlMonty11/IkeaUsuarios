package com.example.montaneralbertomyikea.repositories;

import com.example.montaneralbertomyikea.models.CarritoEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface carritoRepository extends JpaRepository<CarritoEntity,Integer> {
}
