package com.example.montaneralbertomyikea.repositories;


import com.example.montaneralbertomyikea.models.ProductofferEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface productofferRepository extends JpaRepository<ProductofferEntity,Integer> {
}
