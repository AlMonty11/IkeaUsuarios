package com.example.montaneralbertomyikea.repositories;

import com.example.montaneralbertomyikea.models.ProvinciasEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface provinciasRepository extends JpaRepository<ProvinciasEntity,Integer> {
}
