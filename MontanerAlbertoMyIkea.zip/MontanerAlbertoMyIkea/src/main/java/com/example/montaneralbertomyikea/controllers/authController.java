package com.example.montaneralbertomyikea.controllers;

import com.example.montaneralbertomyikea.models.User;
import com.example.montaneralbertomyikea.services.UserService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class authController {
    @Autowired
    private UserService userServiceJPA;

    @GetMapping("/login")
    public String login()
    {
        return "/authentication/login";
    }
    @GetMapping("/login-error")
    public String loginError(Model model) {
        model.addAttribute("loginError", true);
        return "/authentication/login";
    }
    @GetMapping("/register")
    public String registerForm(Model model) {
        model.addAttribute("user", new User());
        return "/authentication/register";
    }
    @PostMapping("/register")
    public String registration(
            @Valid @ModelAttribute("user") User user,
            BindingResult result,
            Model model) {
        User existingUser = userServiceJPA.findUserByEmail(user.getEmail());

        if (existingUser != null)
            result.rejectValue("email", null,
                    "Este usuario ya está registrado !!!");

        if (result.hasErrors()) {
            model.addAttribute("user", user);
            return "authentication/register";
        }

        userServiceJPA.saveUser(user);
        return "redirect:/login";
    }
   /* @GetMapping("/elevarUsuario")
    public String elevarUsuario(Authentication authentication)
    {
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String email = userDetails.getUsername();
        userServiceJPA.elevarUsuario(email);
        return "redirect:/";
    }*/
}
