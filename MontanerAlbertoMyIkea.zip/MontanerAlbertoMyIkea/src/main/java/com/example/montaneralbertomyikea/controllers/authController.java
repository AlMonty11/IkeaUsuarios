package com.example.montaneralbertomyikea.controllers;

import com.example.montaneralbertomyikea.models.User;
import com.example.montaneralbertomyikea.services.UserService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class authController {
    @Autowired
    private UserService userService;

    @GetMapping("/login")
    public String login()
    {
        return "/authentication/login";
    }
    @GetMapping("/login-error")
    public String loginError(Model model) {
        model.addAttribute("loginError", true);
        return "/authentication/login";
    }
    @GetMapping("/register")
    public String registerForm(Model model) {
        model.addAttribute("user", new User());
        return "/authentication/register";
    }
    @PostMapping("/register")
    public String registration(
            @Valid @ModelAttribute("user") User user,
            BindingResult result,
            Model model) {
        User existingUser = userService.findUserByEmail(user.getEmail());

        if (existingUser != null)
            result.rejectValue("email", null,
                    "Este usuario ya está registrado !!!");

        if (result.hasErrors()) {
            model.addAttribute("user", user);
            return "/authentication/register";
        }

        userService.saveUser(user);
        return "redirect:/login";
    }
    @GetMapping("/usuarios")
    public String listarUsuarios(Model model){
        List<User> usuarios = userService.listarUsuarios();
        model.addAttribute("usuarios", usuarios);
        return "/authentication/usuarios";
    }
    @PostMapping("/ascenderManager")
    public String ascenderManager(Authentication authentication)
    {
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String email = userDetails.getUsername();
        userService.addRoleManager(email);
        return "redirect:/";
    }
    @PostMapping("/ascenderAdmin")
    public String ascenderAdmin(Authentication authentication)
    {
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String email = userDetails.getUsername();
        userService.addRoleAdmin(email);
        return "redirect:/";
    }
    @GetMapping("/nuevoRolAdquirido")
    public String confirmacionAscenso(Model model){
        return "/authentication/nuevoRolAdquirido";
    }
}
