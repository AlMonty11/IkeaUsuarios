package com.example.montaneralbertomyikea.interfaces;

import com.example.montaneralbertomyikea.models.CarritoEntity;
import com.example.montaneralbertomyikea.models.ProductofferEntity;

import java.awt.*;
import java.util.List;

public interface carritoService {
}
