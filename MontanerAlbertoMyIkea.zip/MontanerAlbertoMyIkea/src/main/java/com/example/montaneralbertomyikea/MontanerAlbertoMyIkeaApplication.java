package com.example.montaneralbertomyikea;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MontanerAlbertoMyIkeaApplication {

    public static void main(String[] args) {
        SpringApplication.run(MontanerAlbertoMyIkeaApplication.class, args);
    }

}
