package com.example.montaneralbertomyikea.repositories;

import com.example.montaneralbertomyikea.models.MunicipiosEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface municipiosRepository extends JpaRepository<MunicipiosEntity,Integer> {
}
